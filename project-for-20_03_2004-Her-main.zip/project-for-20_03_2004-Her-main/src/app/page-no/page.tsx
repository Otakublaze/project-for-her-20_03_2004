'use client';

import styles from './page.module.css';

export default function Page4No() {
  return (
    <div className={styles.container}>
      <div className={styles.letter}>
        <div className={styles.heart}>🤍</div>

        <h1 className={styles.title}>
          Sukriya hnn Sukriya 🌸
        </h1>

        <p className={styles.text}>
          Sukriya itna sath dene ke liye...
          sukriya itna pyaar dene ke liye....
        </p>

        <p className={styles.text}>
          Ye letter rejection ke liye nahi hai,
          balki us waqt ke liye hai jo humne saath share kiya hai...
        </p>

        <p className={styles.text}>
         hnn agr yes krti to ky hota...vo bhi dekh skti hai...back jakr...
         thik hai.....
          but mujhe umeed hai ki tum samajh jaoge ki mai kya kehna chahta hu...
          and yea love u always...💖...byiii byiii....
          disturb nhi kr rha...
        </p>

        <p className={styles.footer}>
          Take care always 🌸
        </p>
      </div>
    </div>
  );
}
